/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAO;

/**
 *
 * @author Leidy Cuasquer 
 * @version 1.0
 * @Clase en la que se crea los metodos que se van a necesitar en la clase controladorLogin
 */
public interface DAOLogin {
//Con el DAO podemos evitar que accedan facilmente a nuestros metodos de la clase 
 /*contorladorLogin y sean protegidos 
 */ 
    public boolean VerificarUsuarios(String usuario, String contrasenia);
   /* permite verificar el usuario 
    
    */
    public String getUsuario();
    /* permite verificar la contraseña 
    
    */
    public boolean CambiarContrasenia(String contrasenia);
    /* con el boolean va a cambiar la contraseña 
    
    */
    
}
    