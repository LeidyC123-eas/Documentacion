/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import DAO.DAOLogin;

/**
 *
 * @author Leidy Cuasquer 
 * @version 1.0
 * La clase controladorLogin nos permite completar al DAOlogin, con el usuario y la contraseña 
 * 
 */
public class ControladorLogin implements DAOLogin{

    
    private static ControladorLogin controladorLogin;
    private String usuario;
    private String contrasenia;
    
    /**
     * Se inicializa el constructor
     */
    private ControladorLogin() {
        
        
    }
    /**
     * creamos getControladorLogin como static 
     * metodo singleton que verifica la instancia si esta o no el constructor 
     * @return controladorLogin  
     * retorna la instancai del controladorLogin 
     */
    public static ControladorLogin getControladorLogin(){
        if(controladorLogin==null)
            controladorLogin=new ControladorLogin();
        
        return controladorLogin;
    }
    /**
     * 
     * @param usuario
     * @param contrasenia
     * @return estado 
     * Verificar el usuario y contraseña para ingresar 
     */
    @Override
    public boolean VerificarUsuarios(String usuario, String contrasenia) {
        boolean estado=false;
        
        if((usuario.equals("daniel"))&&(contrasenia.equals("12345")))
            estado=true;
        
        return estado;
    }
    
    /**
     * 
     * @return usuario
     * Para el inicio del usuario 
     */

    @Override
    public String getUsuario() {
        return this.usuario;
    }
    /**
     * 
     * @param contrasenia
     * @return estado
     * Sirve para verificacion de la contraseña 
     */

    @Override
    public boolean CambiarContrasenia(String contrasenia) {
        boolean estado=true;        
        this.contrasenia=contrasenia;
        return estado;
        
    }  
}
