/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package empresa;

import Vistas.Login;

/**
 *
 * @author Leidy Cuasquer 
 * @version 1.0
 * @clase donde se encuentra el Main 
 */
public class Empresa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Llamamos a la clase Login y la muestra en pantalla
        Login login=Login.getLogin();
        login.setVisible(true);
    }
    
}
